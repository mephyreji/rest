from rest_framework import serializers
from .models import Menu
from django.contrib.auth.models import User
# class MenuSerializer(serializers.Serializer):
#     dish=serializers.CharField()
#     price=serializers.IntegerField()
#     rating=serializers.IntegerField()
#     category=serializers.CharField()

class MenuModelSer(serializers.ModelSerializer):
    class Meta:
        model=Menu
        fields="__all__"    
    def validate(self, attrs):
        pr=attrs.get("price")    
        if pr<0:
            raise serializers.ValidationError("price should be a non negative value")
        return attrs
    
class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model=User
        fields=["username","password","email"]    
    def create(self, validated_data):
        return User.objects.create_user(**validated_data)    